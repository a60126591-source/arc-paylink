window.ARCPAYLINK_CONFIG = {
  contractAddress: "",
  chainId: 5042002,
  rpcUrl: "https://rpc.testnet.arc.network",
  explorerUrl: "https://testnet.arcscan.app"
};
